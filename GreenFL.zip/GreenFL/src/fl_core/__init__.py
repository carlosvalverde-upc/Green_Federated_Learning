"""
__init__.py del módulo fl_core
"""

from .client import MissionAwareClient, GreenFlowerClient
from .server import FederatedServer, run_server
from .strategies import GreenFedAvg, GreenFedAvgStrategy

__all__ = [
    "MissionAwareClient",
    "GreenFlowerClient",
    "FederatedServer",
    "run_server",
    "GreenFedAvg",
    "GreenFedAvgStrategy",
]
